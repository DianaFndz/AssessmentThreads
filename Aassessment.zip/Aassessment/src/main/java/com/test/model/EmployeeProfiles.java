package com.test.model;

import java.io.Serializable;
import java.util.List;

public class EmployeeProfiles implements Serializable{
	private static final long serialVersionUID = -1773599508061743945L;
	
	
	public List<EmployeeProfile> employeeProfileList;

	public List<EmployeeProfile> getEmployeeProfileList() {
		return employeeProfileList;
	}

	public void setEmployeeProfileList(List<EmployeeProfile> employeeProfileList) {
		this.employeeProfileList = employeeProfileList;
	}

	@Override
	public String toString() {
		return "EmployeeProfile [employeeProfileList=" + employeeProfileList + "]";
	}
	

}

