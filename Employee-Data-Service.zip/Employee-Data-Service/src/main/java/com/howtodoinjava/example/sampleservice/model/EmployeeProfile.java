package com.howtodoinjava.example.sampleservice.model;

import java.io.Serializable;

public class EmployeeProfile implements Serializable {
	
	private static final long serialVersionUID = -1773599508061743945L;
	
	public String profile;
	public String job;
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	
	
	@Override
	public String toString() {
		return "Employeeprofile [profile=" +profile + ", current job=" + job + "]";
	}

}
